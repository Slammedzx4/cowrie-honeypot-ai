### Asking Support Questions

We have an active [discussion forum](https://bit.ly/cowrieslack) where users and developers can ask questions.
Please don't use the GitHub issue tracker to ask questions.
